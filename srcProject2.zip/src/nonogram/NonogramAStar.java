package nonogram;

import astar.AStar;
import astar.Node;
import tools.Constants;
import tools.NonogramLineComparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by espen on 27/10/14.
 */
public class NonogramAStar extends AStar {
    @Override
    protected int calculateH(Node x) {

        NonoNode2 node = (NonoNode2)x;
        int remainingSize = 0;

        for (Line line: node.rows){
            remainingSize += line.domain.size()-1;
        }
        return remainingSize;
    }

    @Override
    public ArrayList<Node> generateAllSuccessors(Node node) {
        NonoNode2 p = (NonoNode2) node;

        List<Line> sortedLines = getLinesSorted(p);
//        Segment bestSegment = getBestSegment(sortedLines);
        Line bestLine = getBestLine(sortedLines);
//        ArrayList<Node> successors = generateNodeFromDomain(bestSegment,p);
        ArrayList<Node> successors = generateNodeFromDomain(bestLine,p);

        return successors;
    }

    private ArrayList<Node> generateNodeFromDomain(Line line, NonoNode2 p) {
        ArrayList<Node> neigbours = new ArrayList<Node>();
        if(line == null){
            return neigbours;
        }
        for (boolean[] assumedElement: line.domain){
            NonoNode2 newNode = p.getDeepCopy();

            Line newLine = newNode.rows.get(line.pos);

            newLine.domain = new ArrayList<boolean[]>();
            newLine.domain.add(assumedElement.clone());

            newNode.assumedRow = newLine;
            neigbours.add(newNode);
        }

        return neigbours;
    }

    private Line getBestLine(List<Line> sortedCells) {
        if(sortedCells.isEmpty())
            return null;
        else
            return sortedCells.get(0);
    }

    private ArrayList<Node> generateNodeFromDomain(Segment segment, NonoNode p) {
            ArrayList<Node> neigbours = new ArrayList<Node>();
            if(segment == null){
                return neigbours;
            }
            for (int start: segment.domain){
                NonoNode newNode = p.getDeepCopy();

                Segment newSegment;
                if(segment.type.equals(Constants.COLUMN))
                    newSegment = newNode.columns.get(segment.line)[segment.pos];
                else
                    newSegment = newNode.rows.get(segment.line)[segment.pos];

                newSegment.start = start;
                newSegment.domain = new ArrayList<Integer>();
                newSegment.domain.add(start);

                newNode.assumedSegment = newSegment;
                neigbours.add(newNode);
            }

            return neigbours;
    }

    private Segment getBestSegment(List<Segment> sortedSegments) {
        if(sortedSegments.isEmpty())
            return null;
        else
            return sortedSegments.get(0);
    }

    private List<Line> getLinesSorted(NonoNode2 node) {
        List<Line> sortedLines = new ArrayList<Line>();
        //sortedLines.addAll(node.columns);
        //sortedLines.addAll(node.rows);

        for (Line line: node.rows){
            if(!line.isSingleton())
                sortedLines.add(line);
        }


        Collections.sort(sortedLines, new NonogramLineComparator());
        for (Line line :sortedLines){
            System.out.print(line + ", ");
        }
        System.out.println();
        return sortedLines;
    }


    private List<Segment> getSegments(ArrayList<Segment[]> list){
        List<Segment> sortedSegments = new ArrayList<Segment>();

        for (Segment[] segments: list){
            for (Segment segment: segments){
                if(segment.isSingleton())
                    continue;
                else
                    sortedSegments.add(segment);
            }
        }
        return sortedSegments;
    }


    @Override
    protected boolean isSolution(Node node) {
        return false;
    }

    @Override
    protected int arcCost(Node parent, Node Child) {
        return 1;
    }

    @Override
    protected void updateUI(Node node) {

    }
}
