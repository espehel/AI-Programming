package nonogram;

import astar.Node;

import java.util.ArrayList;

/**
 * Created by espen on 27/10/14.
 */
public class NonoNode extends Node{

    public ArrayList<Segment[]> columns;
    public ArrayList<Segment[]> rows;
    public ArrayList<ArrayList<boolean[]>> columnPerms;
    public ArrayList<ArrayList<boolean[]>> rowPerms;
    public Segment assumedSegment;

    @Override
    protected boolean isSameState(Node other) {
        return false;
    }

    @Override
    public void generateId() {

    }

    public boolean[][] toGrid(){
        boolean[][] grid = new boolean[columns.size()][rows.size()];


        for (int i = 0; i < columns.size(); i++) {
            for (int j = 0; j < columns.get(i).length; j++) {
                Segment segment = columns.get(i)[j];

                if(segment.isSingleton()){
                    int start = segment.domain.get(0);
                    for (int k = start; k < start+segment.size; k++){
                        grid[segment.line][k] = true;
                    }
                }
            }
        }
        return grid;
    }

    public NonoNode getDeepCopy() {
        NonoNode copy = new NonoNode();

        copy.columns = deepCopyList(this.columns);
        copy.rows = deepCopyList(this.rows);

        return copy;
    }

    private ArrayList<Segment[]> deepCopyList(ArrayList<Segment[]> list){
        ArrayList<Segment[]> copy = new ArrayList<Segment[]>();
        for (Segment[] segments: list) {
            Segment[] newSegments = new Segment[segments.length];
            for (int i = 0; i < segments.length; i++) {
                newSegments[i] = segments[i].getDeepCopy();
            }
            copy.add(newSegments);
        }
        return copy;
    }
}
