package tools;

/**
 * Created by espen on 24/10/14.
 */
public class Constants {
    public static final int DELAY = 50;
    public static final String ROW = "row";
    public static final String COLUMN = "column";

}