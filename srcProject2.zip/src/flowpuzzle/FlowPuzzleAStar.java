package flowpuzzle;

import astar.AStar;
import astar.Node;
import tools.Calculate;
import tools.FlowPuzzleCellComparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by espen on 12/10/14.
 */
public class FlowPuzzleAStar extends AStar {
    @Override
    protected int calculateH(Node node) {
        FPNode x = (FPNode) node;
        /*int domainOptions = 0;
        for (int i = 0; i <x.grid.size; i++) {
            for (int j = 0; j < x.grid[0].size; j++) {
                domainOptions += x.grid[i][j].domain.size()-1;
            }
        }
        return domainOptions;*/
        int totalDistance = 0;
        int flowsConnected = x.flows.length*(x.flows.length*10);
        for (int i = 0; i <x.flows.length; i++) {
            totalDistance += Calculate.manhattenDistance(x.flows[i].head, x.flows[i].end);
            if(x.flows[i].isConnected())
                flowsConnected -= x.flows.length*10;
        }
        return totalDistance;// + flowsConnected;

    }

    @Override
    public ArrayList<Node> generateAllSuccessors(Node node) {

        FPNode p = (FPNode) node;
        //return doEverything(node);

        List<Cell> sortedCells = getHeadsSorted(p);
        Cell bestHead = getBestCell(sortedCells);
        ArrayList<Node> successors = generateNodeFromDomain(bestHead,p);

        return successors;
    }

    private ArrayList<Node> generateNodeFromDomain(Cell cell, FPNode p) {
        ArrayList<Node> neigbours = new ArrayList<Node>();
        if(cell == null){
            return neigbours;
        }

        for(Cell assumee : cell.domain) {
            System.out.println(cell + " assumes output to cell" + assumee);

            FPNode newNode = p.getDeepCopy();

            Cell newAssume = newNode.grid[assumee.x][assumee.y];
            Cell newSource = newNode.grid[cell.x][cell.y];
            //System.out.println("deep copy finished");
            //setts the assumees input to cell in the new grid
            newAssume.input = newSource;

            //sets newSource's domain to the assumee
            newSource.domain = new ArrayList<Cell>();
            newSource.domain.add(newAssume);

            //removes newSource from newAssumes domain
            newAssume.reduceDomain(newSource);

            //sets assumee's colors and flow to cells color and flow.
            newAssume.flow = newSource.flow;
            newAssume.color = newSource.color;

            //System.out.println("setted new assumee fields");

            newAssume.flow.head = new int[]{assumee.x,assumee.y};

            newNode.assumedCell = newAssume;

            //if assumee is an endpoint
            if(assumee.isEndPoint()) {
                System.out.println("Connected to assumed endpoint: " + assumee + "!!!!!!!!!!!!!!!!!!!!!!!!");
            }
            neigbours.add(newNode);
            //System.out.println("added new node");
        }
        return neigbours;
    }

    private Cell getBestCell(List<Cell> sortedCells) {
        for (Cell cell : sortedCells) {
            //if the domain already is 1 this cell is skipped
            //if (cell.domain.size() <= 1)
              //  continue;
            return cell;
        }
        return null;
    }

    private List<Cell> getHeadsSorted(FPNode node) {
        List<Cell> sortedCells = new ArrayList<Cell>();

        for (Flow flow: node.flows){
            Cell head = node.getHead(flow);

            head.propageteFlow();

            if(head.isEndPoint())
                continue;
            else{
                sortedCells.add(head);
            }
        }
        Collections.sort(sortedCells,new FlowPuzzleCellComparator());
        for (Cell cell :sortedCells){
            System.out.print(cell + ", ");
        }
        System.out.println();
        return sortedCells;
    }

    @Override
    protected boolean isSolution(Node node) {
        return false;
    }

    @Override
    protected int arcCost(Node parent, Node Child) {
        return 1;
    }//TODO: check if this is correct

    @Override
    protected void updateUI(Node node) {

    }
}
