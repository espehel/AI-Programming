package csp.gac;

/**
 * Created by espen on 01/10/14.
 */
public class Revise {

    public String constraint;

    public Revise(String constraint) {
        this.constraint = constraint;
    }
}
