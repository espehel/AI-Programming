package csp.gac;

import astar.AStar;
import astar.Node;
import javafx.scene.paint.Color;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

/**
 * Created by espen on 20/09/14.
 */
public abstract class AStarGAC {


    protected abstract void initialize(Node x);
    public abstract Node generateInitialNode();
    protected abstract void domainFilteringLoop(Node x);
    protected abstract boolean isSolution(Node node);
    protected abstract boolean isContradictary(Node node);
    protected abstract void GACRerun(Node node);
    public abstract void setup(List<Color> domain, Vertex[] vertices, ArrayList<Edge> edges);
    protected AStar search;
    public Queue<VCRevise> queue;

    public AStarGAC(AStar search){
        this.search = search;
        queue = new ArrayDeque<VCRevise>();
    }


    public Node run(){

        //initial phase
        Node x = generateInitialNode();
        search.initialize(x);
        initialize(x);
        domainFilteringLoop(x);
        if(isSolution(x)){
            return x;
        }
        if(isContradictary(x)){
            return null;
        }


        //do assumptions (searching)
        while(!search.open.isEmpty()) {
            //System.out.println("Open size: " + search.open.size());
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            x = search.pop(search.open);
            search.counter++;
            search.closed.add(x);
            updateUI(x);
            System.out.println("H: " + x.h);
            //System.out.println("F: " + x.f());
            int j = 0;
            /*for (Vertex vertex : ((VCNode)x).vertices){
                System.out.println("vertex: " + j++ + ", domain: " + vertex.domain.size());
            }*/
            if(isSolution(x)) {
                printStats(x,search);

                return x;
            }

            ArrayList<Node> successors = search.generateAllSuccessors(x);
            ArrayList<Node> badSuccesssors = new ArrayList<Node>();
            for (Node node : successors){
                queue.clear();
                try {
                    //doing domain filtering on all the successors
                    GACRerun(node);
                //cathes an exception if a successors ends up with a variable that has an empty domain
                }catch (IllegalStateException e){
                    System.out.println("Dead end");
                    badSuccesssors.add(node);
                    //sets the h value to max since it will never be completed and adds it to the closed list
                    node.h = Integer.MAX_VALUE;
                    search.closed.add(node);
                }
            }
            //removes successors that has hit a dead end.
            successors.removeAll(badSuccesssors);
            //evaluates the successors so the best sucessors will be popped.
            search.evalSuccesors(successors, x);
        }
        return x;
    }

    protected abstract void printStats(Node x, AStar search);

    protected abstract void updateUI(Node node);


}
