package astar;

public class Controller {
}
